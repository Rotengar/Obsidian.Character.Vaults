---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Individual
FeatCategory: People
FeatType: World Almanac
---
# <center>Template - Individual</center>

## Encounter
```encounter
name: Example
creatures:
 - 3: Goblin
```


## Stat-Block
```statblock

monster: Commoner

```

## Overview

**Alignment**: Neutral

**Gender**: Male

**Race**: Human

**Class**: Barbarian

**Age**: Adult

**Challenge**: CR 1

**Character Role**: Friend

**Condition**: Dead
![Placeholder Portrait!](ImagePlaceholder.png)
Placeholder​

## Profile

**Appearance Traits**: Stylish

**Social Traits**: Bossy
<table><tbody><tr><td>
STR
</td><td>
DEX
</td><td>
CON
</td><td>
WIS
</td><td>
INT
</td><td>
CHA
</td></tr><tr><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td></tr></tbody></table>

## Story

Placeholder​

## Motivation and Philosophy

**Mental Traits**: Ambitious

Placeholder​

## Personal Life

Placeholder​

## Professional Life

**Expertise**: Administrative

Placeholder​

## Other Endeavors

Placeholder​

## Possessions

**Special Equipment**: Placeholder​

Placeholder​

## Resources

**Status Traits**: Lucky

Placeholder​

## Abilities

**Physical Traits**: Clumsy

Placeholder​

## Methods

**Personality Traits**: Anxious

Placeholder​

## Background

**Birth Date**: 01/01/20000 BCE 00:00:00

**Marriage Date**: 01/01/20000 BCE 00:00:00

**Death Date**: 01/01/20000 BCE 00:00:00

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Deity]] | [[Group List]] | [[Templates]] |
