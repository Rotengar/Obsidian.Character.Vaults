---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Plot-Idea
FeatCategory: Other
FeatType: World Almanac
---
# <center>Template - Plot Idea</center>

## Overview

**Genre**: Alternative History

**Tone**: Action

**Plot Structure**: Branching

**Plot Focus**: Exploration

Placeholder

## Synopsis

Placeholder

## Key People, Places, and Things

Placeholder

## Scene Outline

Placeholder

## Setup

Placeholder

## Details

Placeholder

## Resolution

Placeholder

## Campaign Integration

Placeholder

## Additional Details

**Genre Easily Adapted To**: Alternative History

**Tone Easily Adapted To**: Action

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Plot Hook]] | [[Story Gallery]] | [[Templates]] |
