---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Scene
FeatCategory: Events
FeatType: World Almanac

---
# <center>Template - Scene</center>

## Overview

**Scene Type**: Conclusion

**Setting**: Extradimensional

**Encounter Type**: Exploration
![Image!](ImagePlaceholder.png)
Placeholder

## Setup
![Map!](MapPlaceholder.png)
Placeholder

## Participants

Placeholder - Encounter Code

Placeholder - Statblock Code
![Placeholder Portrait!](ImagePlaceholder.png)
Placeholder​ 

## Challenge

Placeholder​ 

## Obstacles

Placeholder​ 

## Rewards

Placeholder​ 

## Background

Placeholder​ 

## Additional Details

Placeholder​ 


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Quest]] | [[Storyline]] | [[Templates]] |
