---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Disease
FeatCategory: Dangers
FeatType: Mechanics Reference
---
# <center>Template - Disease</center>

## Overview

Placeholder

## Becoming Afflicted

Placeholder

## Effects

Placeholder

## Prevention and Recovery

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Creature]] | [[General Dangers Article]] | [[Templates]] |
