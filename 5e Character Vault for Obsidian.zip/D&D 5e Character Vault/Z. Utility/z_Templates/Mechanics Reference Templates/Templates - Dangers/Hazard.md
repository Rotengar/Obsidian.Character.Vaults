---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Hazard
FeatCategory: Dangers
FeatType: Mechanics Reference
---
# <center>Template - Hazard</center>

## Overview

Placeholder

## Conditions

Placeholder

## Effects

Placeholder

## Avoidance and Mitigation

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[General Dangers Article]] | [[Poison]] | [[Templates]] |
