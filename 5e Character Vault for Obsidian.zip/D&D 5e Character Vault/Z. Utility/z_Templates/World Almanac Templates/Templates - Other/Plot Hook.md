---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Plot-Hook
FeatCategory: Other
FeatType: World Almanac
---
# <center>Template - Plot Hook</center>

## Overview

Placeholder

## Hook

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Other List]] | [[Plot Idea]] | [[Templates]] |
