---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Named-Vehicle
FeatCategory: Things
FeatType: World Almanac
---
# <center>Template - Named Vehicle</center>

## Overview

**Transport Medium**: Land
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder

## Profile

Placeholder

## Story

Placeholder

## Relationships

Placeholder

## Transportation

Placeholder

## Operation

Placeholder

## Capabilities

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Named Object]] | [[Object Collection]] | [[Templates]] |
