---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Adventure-Area
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Adventure Area</center>

## Overview

**Type**: Building

Placeholder​

## Description
![Placeholder Map!](MapPlaceholder.png)![Placeholder Picture!](ImagePlaceholder.png)
Placeholder​

## Notable NPCs

Placeholder​

## Story

Placeholder​

## Points of Interest

Placeholder​

## Valuables

Placeholder​

## Challenges

Placeholder​

## Obstacles

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Group_ Religious\|Group: Religious]] | [[Location]] | [[Templates]] |
