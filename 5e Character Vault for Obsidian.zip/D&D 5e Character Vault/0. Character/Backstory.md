^^ [[Character Sheet]] | << [[Magic]] | [[Class Abilities]] >>
# Backstory

## Basic Information
Name:
Age:
Gender:
Sexuality:
Date of Birth:
Height:
Weight:

### Family

Parental Figure Name or Names:
Race: (if not the same as yours)
Occupation: 
Relationship:

Sibling
Race: (if not the same as yours)
Occupation:
Relationship:


## Personal Characteristics
### Ideals
-

### Bonds
-

### Flaws
-


## Pre-adventuring Days

### Growing up...


### Teen years


### Young adulthood


`### Adult hood`
`### Middle Age`
`### Elder Years`



### Allies and Antagonists

*Friends*
- NPC
- NPC
- NPC

*Contacts*
- NPC
- NPC
- NPC

*Enemies*
- NPC
- NPC
- NPC