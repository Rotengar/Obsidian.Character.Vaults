---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Player-Synopsis
FeatCategory: Sources
FeatType: World Almanac
---
# <center>Template - Player Synopsis</center>

## Overview

Placeholder

## Important Places

Placeholder

## Important Characters

Placeholder

## Important Plot Elements

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[GM Synopsis]] | [[Story Source]] | [[Templates]] |
