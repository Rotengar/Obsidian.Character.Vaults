---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
FeatCategory: Ignore
FeatType: Ignore
banner: z_Templates/z_asset-files/Templates_Small.png
banner_x: 0.5
banner_y: 0.628
---



# <center>Templates</center>

## World Almanac Templates
```dataview
table FeatType, FeatCategory
from "z_Templates"
where (FeatType != "Ignore")
where (FeatType = "World Almanac")
```

## Mechanics Reference Templates
```dataview
table FeatType, FeatCategory
from "z_Templates"
where (FeatType != "Ignore")
where (FeatType = "Mechanics Reference")
```
