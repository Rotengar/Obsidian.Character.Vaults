---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Time-Period
FeatCategory: Events
FeatType: World Almanac
---
# <center>Template - Time Period</center>

## Overview

**Time Span**: From: 01/01/20000 BCE 00:00:00 To: 01/01/20000 BCE 00:00:00

Placeholder​

## Description

Placeholder​

## Location

Placeholder​

## Causes and Effects

Placeholder​

## Story

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Storyline]] | [[Cast List]] | [[Templates]] |
