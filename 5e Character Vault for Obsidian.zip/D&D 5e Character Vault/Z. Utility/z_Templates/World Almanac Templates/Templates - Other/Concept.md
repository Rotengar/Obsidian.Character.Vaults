---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Concept
FeatCategory: Other
FeatType: World Almanac
---
# <center>Template - Concept</center>

## Overview

Placeholder

## Description

Placeholder

## Story

Placeholder

## Origin

Placeholder

## Downfall

Placeholder

## Proponents

Placeholder

## Detractors

Placeholder

## Counterparts

Placeholder

## Opposition

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Thing List]] | [[Further Information]] | [[Templates]] |
