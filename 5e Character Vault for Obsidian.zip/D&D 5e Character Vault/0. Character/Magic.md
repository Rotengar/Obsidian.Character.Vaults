^^ [[Character Sheet]] | << [[Inventory]] | [[Backstory]] >>

# Magic
Magical Subclass:
Spell Focus Type:
Spell Attack Bonus: +0, **Roll:** `dice: 1d20+0`
Spell Save DC: 10

Cantrips Known:
Spells Prepared:

### Spell Slots
| ~~~         | 1st | 2nd | 3rd | 4th | 5th | 6th | 7th | 8th | 9th |
| --------- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Remaining |     |     |     |     |     |     |     |     |     |
| Maximum       |     |     |     |     |     |     |     |     |     |

### Component Pouch
- Belladonna
- Mugwort
- Frost Salt
- Aconite

## Spellbook

### Cantrips

### 1st Level

### 2nd Level

### 3rd Level

### 4th Level

### 5th Level

### 6th Level

### 7th Level

### 8th Level

### 9th Level

