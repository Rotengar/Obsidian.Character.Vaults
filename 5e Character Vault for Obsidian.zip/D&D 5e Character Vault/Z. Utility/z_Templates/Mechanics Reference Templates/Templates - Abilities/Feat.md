---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Feat
FeatCategory: Abilities
FeatType: Mechanics Reference
---
# <center>Template - Feat</center>

## Overview

Placeholder

## Requirements and Restrictions

**Prerequisite**: Placeholder

Placeholder

## Effects

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Vehicle]] | [[General Abilities Article]] | [[Templates]] |
