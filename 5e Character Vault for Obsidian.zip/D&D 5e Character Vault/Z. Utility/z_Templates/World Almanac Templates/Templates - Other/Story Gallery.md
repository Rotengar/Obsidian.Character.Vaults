---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Story-Gallery
FeatCategory: Other
FeatType: World Almanac
---
# <center>Template - Story Gallery</center>

## Overview

Placeholder

## Gallery
![Placeholder Portrait!](ImagePlaceholder.png)![Placeholder Scenic!](ImagePlaceholder.png)![Placeholder Map!](MapPlaceholder.png)
Placeholder

## Additional Details

**Keywords**: Placeholder

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Plot Idea]] | [[Titled Position]] | [[Templates]] |
