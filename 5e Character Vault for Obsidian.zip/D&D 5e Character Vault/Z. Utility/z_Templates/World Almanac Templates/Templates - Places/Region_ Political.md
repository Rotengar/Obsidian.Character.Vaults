---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Region--Political
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Region: Political</center>

## Overview

**Political Region**: Nation

**Alignment**: Chaotic Evil

**Seat of Power**: Placeholder​

**Major Races/Ethnicities**: Placeholder​

**Government**: Placeholder​

**Languages**: Placeholder​

**Religion**: Placeholder​
![Placeholder Flag/Symbol!](ImagePlaceholder.png)
Placeholder​

## Description
![Placeholder Map!](MapPlaceholder.png)
Placeholder​

## Notable NPCs

Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Points of Interest

Placeholder​

## Resources

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Region_ Geographical\|Region: Geographical]] | [[Region_ Area\|Region: Area]] | [[Templates]] |
