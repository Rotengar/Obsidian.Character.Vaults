^^ [[Character Sheet]] | << [[Combat]] | [[Magic]] >> 

# Inventory
Current Weight:

| Encumbered Weight | Heavily Encumbered | Max Carry |     
| ----------------- | ------------------ | --------- | 
| (STRx5)           | (STRx10)           | (STRx15)  |     

## Gold & Wealth
| Type          | Amount |
| ------------- | ------ |
| Copper (CP)   |        |
| Silver (SP)   |        |
| Electrum (EP) |        |
| Gold (GP)     |        |
| Platinum (PP) |        |

### Other wealth (Titles, Lands, etc)

## Armor & Shields

## Weapons

## Consumables

## Gear

## Wands and Rings

## Tools

## Quest related items

## Other
- Chocolates 
- Promises you don't intend to keep
