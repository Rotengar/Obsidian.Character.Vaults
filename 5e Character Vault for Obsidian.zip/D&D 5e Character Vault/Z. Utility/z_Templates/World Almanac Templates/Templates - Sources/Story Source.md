---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Story-Source
FeatCategory: Sources
FeatType: World Almanac
---
# <center>Template - Story Source</center>

## Overview

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Player Synopsis]] | [[Mechanics Source]] | [[Templates]] |
