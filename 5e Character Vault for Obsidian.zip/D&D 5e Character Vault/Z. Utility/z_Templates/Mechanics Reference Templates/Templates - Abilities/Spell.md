---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Spell
FeatCategory: Abilities
FeatType: Mechanics Reference
---
# <center>Template - Spell</center>

## Overview

**Class**: Barbarian

**Level**: 1st

**School**: Evocation

**Special Nature**: Ritual

**Casting Time**: Placeholder

**Range**: Placeholder

**Components**: Placeholder

**Duration**: Placeholder

Placeholder

## Requirements and Restrictions

Placeholder

## Effects

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Skill]] | [[Campaign Element]] | [[Templates]] |
