---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Group--Criminal
FeatCategory: Groups
FeatType: World Almanac
---
# <center>Template - Group: Criminal</center>

## Overview

**Type**: Criminal

**Alignment**: Chaotic Evil

**Criminal Activities**: Vice

**Criminal Organization**: Cartel
![Placeholder Iconography!](ImagePlaceholder.png)
Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Philosophy

Placeholder​

## Relationships

Placeholder​

## Organization

**Headquarters**: Placeholder​

**Leader(s)**: Placeholder​

**Prominent Members**: Placeholder​

Placeholder​

## Resources

Placeholder​

## Methods

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Group_ Commerce\|Group: Commerce]] | [[Group_ Ethnic\|Group: Ethnic]] | [[Templates]] |
