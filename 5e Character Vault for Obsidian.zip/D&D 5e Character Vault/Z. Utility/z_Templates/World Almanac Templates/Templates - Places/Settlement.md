---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Settlement
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Settlement</center>

## Overview

**Community Size**: Outpost

**Alignment**: Chaotic Evil

**Government**: Autocracy

**Defense**: Placeholder​

**Commerce**: Placeholder​

**Organizations**: Placeholder​

Placeholder​

## Description

**Population**: Placeholder​
![Placeholder Map!](MapPlaceholder.png)![Placeholder Picture!](ImagePlaceholder.png)
Placeholder

## Notable NPCs

Placeholder

## Profile

Placeholder

## Story

Placeholder

## Points of Interest

Placeholder

## Valuables

Placeholder

## Internal Relationships

Placeholder

## Outward Relationships

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Region_ Area\|Region: Area]] | [[Inhabitant]] | [[Templates]] |
