---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Region--Urban
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Region: Area</center>

## Overview

**Urban Region**: Precinct

**Usage**: Other
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder​

## Description
![Placeholder Map!](MapPlaceholder.png)
Placeholder​

## Notable NPCs

Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Points of Interest

Placeholder​

## Resources

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Region_ Political\|Region: Political]] | [[Settlement]] | [[Templates]] |
