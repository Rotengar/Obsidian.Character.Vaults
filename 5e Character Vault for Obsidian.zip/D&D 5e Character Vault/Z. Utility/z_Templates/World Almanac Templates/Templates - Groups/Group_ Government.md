---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Group--Government
FeatCategory: Groups
FeatType: World Almanac
---
# <center>Template - Group: Government</center>

## Overview

**Type**: Government

**Alignment**: Chaotic Evil

**Government Role**: Exploration

**Government Organization**: Administration
![Placeholder Iconography!](ImagePlaceholder.png)
Placeholder​

## Profile

Placeholder​

## Powers and Duties

Placeholder​

## Story

Placeholder​

## Philosophy

Placeholder​

## Relationships

Placeholder​

## Organization

**Headquarters**: Placeholder​

**Leader(s)**: Placeholder​

**Prominent Members**: Placeholder​

Placeholder​

## Resources

Placeholder​

## Methods

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Group_ Family\|Group: Family]] | [[Group_ Military\|Group: Military]] | [[Templates]] |
