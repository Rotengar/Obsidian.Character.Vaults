---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Mundane-Armor-Shield
FeatCategory: Equipment
FeatType: Mechanics Reference
---
# <center>Template - Mundane Armor/Shield</center>

## Overview

**Price**: Placeholder
![Placeholder Picture!](ImagePlaceholder.png)
**Weight**: Placeholder

**Type**: Light Armor

**Armor Class**: Placeholder

**Min. Strength**: Placeholder

**Stealth**: Placeholder

Placeholder

## Description

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Magic Item]] | [[Mundane Item]] | [[Templates]] |
