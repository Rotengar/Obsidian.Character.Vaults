---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Trap
FeatCategory: Dangers
FeatType: Mechanics Reference
---
# <center>Template - Trap</center>

## Overview

Placeholder

## Conditions

Placeholder

## Effects

Placeholder

## Avoidance and Mitigation

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Poison]] | [[General Game Mastering Article]] | [[Templates]] |
