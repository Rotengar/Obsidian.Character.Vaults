---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Merchant
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Merchant</center>

## Overview

Placeholder​

## Goods and Services

**Goods Sold**: Consumable Item

**Services Sold**: Information

Placeholder​

## Profile

**Prices**: Cheap

**Quality**: Average

Placeholder​

## Story

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Location]] | [[Place List]] | [[Templates]] |
