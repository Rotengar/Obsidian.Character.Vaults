^^ [[Character Sheet]] | << [[Class Abilities]] | [[Inventory]] >> 
# Combat
| AC  | Initiative        | Speed |
| --- | ----------------- | ----- |
| **10**  | +0,  **Roll:** `dice: 1d20+0` | 30ft  |

### Attacks
#### Melee Attacks
| Attack | To Hit | Damage                    | Special |
| ------ | ------ | ------------------------- | ------- |
| Dagger | +2     | 1d4+2 Piercing, **Roll:** `dice: 1d4+2` | Extra Stabby        |

#### Range Attacks
| Attack | To Hit | Damage                              |  Range   | Special               |
| ------ | ------ | ----------------------------------- | --- | --------------------- |
| Rooty-Tootie-Point-n-Shooty (bow)	| +2     | 1d8 Piercing, **Roll:** `dice: 1d8` | 120'    | Stab people far away! |

#### Ammunition
| Type   | Amount |
| ------ | ------ |
| Arrows | 20       |

### Health
| Current HP | Max HP | Temp HP | Remaining HD | 
| ---------- | ------ | ------- | ------------ |
|            |        |         |      1        |

Hit Die Type:
Max HD:
 
***Death Saves***

- [ ]  Success 1
- [ ] Success 2
- [ ] Success 3

- [ ] Failure 1
- [ ] Failure 2
- [ ] Failure 3
