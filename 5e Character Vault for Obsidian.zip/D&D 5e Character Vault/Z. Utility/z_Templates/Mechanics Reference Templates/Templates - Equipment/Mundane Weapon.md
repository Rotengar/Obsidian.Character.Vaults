---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Mundane-Weapon
FeatCategory: Equipment
FeatType: Mechanics Reference
---
# <center>Template - Mundane Weapon</center>

## Overview

**Price**: Placeholder
![Placeholder Picture!](ImagePlaceholder.png)
**Weight**: Placeholder

**Type**: Martial Melee Weapons

**Era**: Medieval Item

**Damage**: Placeholder

**Properties**: Placeholder

Placeholder

## Description

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Mundane Item]] | [[Vehicle]] | [[Templates]] |
