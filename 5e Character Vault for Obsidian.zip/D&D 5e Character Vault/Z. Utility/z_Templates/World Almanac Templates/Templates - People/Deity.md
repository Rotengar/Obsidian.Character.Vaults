---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Deity
FeatCategory: People
FeatType: World Almanac
---
# <center>Template - Deity</center>
## Encounter
```encounter
name: Example
creatures:
 - 3: Goblin
```


## Stat-Block
```statblock

monster: Commoner

```

## Overview

Placeholder​

**Alignment**: Chaotic Evil

**Domains**: Death
![Holy Symbol!](ImagePlaceholder.png "
**Holy Symbol**: Placeholder​
")![Picture!](ImagePlaceholder.png "
**Picture**: Placeholder​
")
## Profile
<table><tbody><tr><td>
STR
</td><td>
DEX
</td><td>
CON
</td><td>
WIS
</td><td>
INT
</td><td>
CHA
</td></tr><tr><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td></tr></tbody></table>
 

Placeholder​

## Story

Placeholder​

## Motivation and Philosophy

Placeholder​

## Relationships

Placeholder​

## Resources

Placeholder​

## Abilities

Placeholder​

## Methods

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Cast List]] | [[Individual]] | [[Templates]] |
