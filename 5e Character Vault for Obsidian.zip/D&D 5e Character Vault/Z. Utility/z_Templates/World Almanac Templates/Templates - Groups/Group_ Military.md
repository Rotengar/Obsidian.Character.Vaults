---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Group--Military
FeatCategory: Groups
FeatType: World Almanac
---
# <center>Template - Group: Military</center>

## Overview

**Type**: Military

**Alignment**: Chaotic Evil​​

**Military Role**: Air

**Military Organization**: Air Force
![Placeholder Iconography!](ImagePlaceholder.png)
Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Philosophy

Placeholder​

## Relationships

Placeholder​

## Organization

**Headquarters**: Placeholder​

**Leader(s)**: Placeholder​

**Prominent Members**: Placeholder​

Placeholder​

## Forces and Resources

Placeholder​

## Methods

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Group_ Government\|Group: Government]] | [[Group_ Other\|Group: Other]] | [[Templates]] |
