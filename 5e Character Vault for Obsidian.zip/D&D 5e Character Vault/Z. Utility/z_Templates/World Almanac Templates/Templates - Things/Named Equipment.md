---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Named-Equipment
FeatCategory: Things
FeatType: World Almanac
---
# <center>Template - Named Equipment</center>

## Overview

**Equipment Type**: Weapon
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder

## Profile

Placeholder

## Story

Placeholder

## Relationships

Placeholder

## Equipping

Placeholder

## Capabilities

Placeholder

## Components

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Inhabitant]] | [[Named Object]] | [[Templates]] |
