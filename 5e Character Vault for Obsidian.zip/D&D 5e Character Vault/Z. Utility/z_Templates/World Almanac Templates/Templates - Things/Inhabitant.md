---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Inhabitant
FeatCategory: Things
FeatType: World Almanac
---
# <center>Template - Inhabitant</center>

## Overview
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder

## Profile

Placeholder

## Story

Placeholder

## Relationships

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Settlement]] | [[Named Equipment]] | [[Templates]] |
