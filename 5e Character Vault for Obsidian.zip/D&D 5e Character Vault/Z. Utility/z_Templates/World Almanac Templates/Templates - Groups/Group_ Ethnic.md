---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Group--Ethnic
FeatCategory: Groups
FeatType: World Almanac
---
# <center>Template - Group: Ethnic</center>

## Overview

**Type**: Ethnic

**Ethnic Identity**: Homeland
![Placeholder Iconography!](ImagePlaceholder.png)
Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Philosophy

Placeholder​

## Relationships

Placeholder​

## Organization

Placeholder​

## Resources

Placeholder​

## Methods

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Group_ Criminal\|Group: Criminal]] | [[Group_ Family\|Group: Family]] | [[Templates]] |
