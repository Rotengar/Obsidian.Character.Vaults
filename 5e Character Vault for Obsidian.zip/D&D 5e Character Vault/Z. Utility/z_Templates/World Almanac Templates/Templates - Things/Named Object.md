---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Named-Object
FeatCategory: Things
FeatType: World Almanac
---
# <center>Template - Named Object</center>

## Overview
![Placeholder Picture!](ImagePlaceholder.png "
**Placeholder Picture**: Placeholder
")
Placeholder

## Profile

Placeholder

## Story

Placeholder

## Relationships

Placeholder

## Capabilities

Placeholder

## Components

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Named Equipment]] | [[Named Vehicle]] | [[Templates]] |
