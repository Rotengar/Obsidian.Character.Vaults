---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Location
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Location</center>

## Overview

**Type**: Area

Placeholder​

## Description
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Points of Interest

Placeholder​

## Valuables

Placeholder​

## Challenges

Placeholder​

## Obstacles

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Adventure Area]] | [[Merchant]] | [[Templates]] |
