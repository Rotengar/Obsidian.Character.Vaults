---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Titled-Position
FeatCategory: Other
FeatType: World Almanac
---
# <center>Template - Titled Position</center>

## Overview

**Position Type**: Internal Operations

**Rank**: Junior MemberPlaceholder
![Placeholder Iconography!](ImagePlaceholder.png)
Placeholder

## Description

Placeholder

## Requirements

Placeholder

## Powers and Benefits

Placeholder

## Duties and Responsibilities

Placeholder

## Story

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Story Gallery]] | [[GM Synopsis]] | [[Templates]] |
