---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Poison
FeatCategory: Dangers
FeatType: Mechanics Reference
---
# <center>Template - Poison</center>

## Overview

**Type**: Injury

**Price**: Placeholder

Placeholder

## Becoming Afflicted

Placeholder

## Effects

Placeholder

## Prevention and Recovery

Placeholder

## Obtaining

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Hazard]] | [[Trap]] | [[Templates]] |
