---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Region--Geographical
FeatCategory: Places
FeatType: World Almanac
---
# <center>Template - Region: Geographical</center>

## Overview

**Geographical Region**: Mountains
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder​

## Description

**Terrain**: Swamp

**Climate**: Arctic 
![Placeholder Map!](MapPlaceholder.png)
Placeholder​

## Notable NPCs

Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Points of Interest

Placeholder​

## Resources

Placeholder​

## Relationships

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Region_ Deimensional\|Region: Deimensional]] | [[Region_ Political\|Region: Political]] | [[Templates]] |
