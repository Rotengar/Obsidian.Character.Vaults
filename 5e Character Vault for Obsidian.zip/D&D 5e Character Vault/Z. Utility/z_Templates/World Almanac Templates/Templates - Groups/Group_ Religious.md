---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Group--Religious
FeatCategory: Groups
FeatType: World Almanac
---
# <center>Template - Group: Religious</center>

## Overview

**Type**: Religious

**Alignment**: Chaotic Evil

**Religious Organization**: House of Worship
![Placeholder Iconography!](ImagePlaceholder.png)
Placeholder​

## Profile

Placeholder​

## Story

Placeholder​

## Faith and Beliefs

Placeholder​

## Relationships

Placeholder​

## Organization

**Headquarters**: Placeholder​

**Leader(s)**: Placeholder​

**Prominent Members**: Placeholder​

Placeholder​

## Resources

Placeholder​

## Methods

Placeholder​

## Background

Placeholder​

## Additional Details

Placeholder​


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Group_ Other\|Group: Other]] | [[Adventure Area]] | [[Templates]] |
