---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Mundane-Item
FeatCategory: Equipment
FeatType: Mechanics Reference
---
# <center>Template - Mundane Item</center>

## Overview

**Price**: Placeholder

**Weight**: Placeholder
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder

## Description

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Mundane Armor_Shield\|Mundane Armor/Shield]] | [[Mundane Weapon]] | [[Templates]] |
