---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Creature
FeatCategory: Dangers
FeatType: Mechanics Reference
---
# <center>Template - Creature</center>
## Encounter
```encounter
name: Example
creatures:
 - 3: Goblin
```


## Stat-Block
```statblock

monster: Commoner

```

## Overview
![Placeholder Portrait!](ImagePlaceholder.png)
**Alignment**: Neutral

**Armor Class**: Placeholder

**Hit Points**: Placeholder

**Speed**: Placeholder

**Challenge**: CR 1

**Experience**: Placeholder

Placeholder

## Other Details
<table>**Ability Scores**: <tbody><tr><td>
STR
</td><td>
DEX
</td><td>
CON
</td><td>
WIS
</td><td>
INT
</td><td>
CHA
</td></tr><tr><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td><td>
0(+0)
</td></tr></tbody></table>

**Saving Throws**: Placeholder

**Skills**: Placeholder

**Damage Vulnerabilities**: Placeholder

**Damage Resistances**: Placeholder

**Damage Immunities**: Placeholder

**Condition Immunities**: Placeholder

**Senses**: Placeholder

**Languages**: Placeholder

**Size**: Medium

**Type**: Humanoid

**Creature Tags**: Aarakocra

Placeholder

## Special Traits

Placeholder

## Actions

Placeholder

## Reactions

Placeholder

## Legendary Actions

Placeholder

## Description

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[General Gameplay Article]] | [[Disease]] | [[Templates]] |
