---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Background
FeatCategory: Characters
FeatType: Mechanics Reference
---
# <center>Template - Background</center>

## Overview

Placeholder

## Requirements and Restrictions

Placeholder

## Effects

Placeholder

## Conditions

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Archetype_Domain_Etc.\|Archetype/Domain/Etc.]] | [[Class]] | [[Templates]] |
