---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Magic-Item
FeatCategory: Equipment
FeatType: Mechanics Reference
---
# <center>Template - Magic Item</center>

## Overview

**Type**: Magic Item

**Group**: Wondrous Items

**Rarity**: Common

**Attunement**: Placeholder
![Placeholder Picture!](ImagePlaceholder.png)
Placeholder

## Description

Placeholder

## Construction

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[General Equipment Article]] | [[Mundane Armor_Shield\|Mundane Armor/Shield]] | [[Templates]] |
