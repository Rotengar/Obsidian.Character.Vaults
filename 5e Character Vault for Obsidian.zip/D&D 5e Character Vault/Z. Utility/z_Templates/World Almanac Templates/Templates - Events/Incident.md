---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Incident
FeatCategory: Events
FeatType: World Almanac
---
# <center>Template - Incident</center>

## Overview

**Date**: 01/01/20000 BCE 00:00:00

Placeholder

## Description

Placeholder

## Location

Placeholder

## Causes and Effects

Placeholder

## Story

Placeholder

## Relationships

Placeholder

## Background

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Event List]] | [[Quest]] | [[Templates]] |
