---
ImportedOn: Saturday, 4 December 2021 8:29:25 PM
Tags: Vehicle
FeatCategory: Equipment
FeatType: Mechanics Reference
---
# <center>Template - Vehicle</center>

## Overview
![Placeholder Picture!](ImagePlaceholder.png)
**AC**: Placeholder

**Price**: Placeholder

**Speed**: Placeholder

**Crew**: Placeholder

**Passengers**: Placeholder

**Cargo (tons)**: Placeholder

**HP**: Placeholder

**Damage Threshold**: Placeholder

Placeholder

## Description

Placeholder

## Additional Details

Placeholder


---
## Navigation
| Up | Prev | Next | Home |
|----|------|------|------|
| [[Templates]] | [[Mundane Weapon]] | [[Feat]] | [[Templates]] |
